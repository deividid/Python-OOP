from project.elf import Elf


class MuseElf(Elf):
    pass