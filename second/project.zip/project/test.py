from second.project.animal import Animal
from second.project.dog import Dog

beast = Animal()
sheppard = Dog()

print(beast.eat())
print(sheppard.bark())
print(sheppard.eat())
